/* Minimal DXF (AutoCAD R2000 / AC1015) writer: closed LWPOLYLINEs on named layers, $INSUNITS set.
   Also: selection/clip/split logic (uses polygon-clipping) and a tiny ZIP writer. No other dependencies. */
(function (root) {
  "use strict";
  const pc = () => (typeof polygonClipping !== "undefined" ? polygonClipping : require("./polygon-clipping.umd.min.js"));

  // ------------------------------------------------------------------ DXF writer
  const num = v => { if (Math.abs(v) < 1e-12) v = 0; let s = v.toFixed(6); if (s.indexOf(".") >= 0) s = s.replace(/0+$/, "").replace(/\.$/, ""); return s === "-0" ? "0" : s; };

  /** Legacy helper: groups [{name, polys:[[ [x,y],.. ]]}] (all closed) -> writeEntities. */
  function writeDxf(groups, unit) {
    return writeEntities(groups.flatMap(g => g.polys.map(q => ({ layer: g.name, pts: q, closed: true }))), unit);
  }

  /** entities: [{layer, pts:[[x,y],..], closed}] in output units (y up), written in the given order. unit 'mm'|'in'. */
  function writeEntities(entities, unit) {
    const groups = [];
    { const idx = {}; entities.forEach(e => { if (!(e.layer in idx)) { idx[e.layer] = groups.length; groups.push({ name: e.layer, polys: [] }); } groups[idx[e.layer]].polys.push(e.pts); }); }
    let seed = 0x30; const H = () => (seed++).toString(16).toUpperCase();
    const out = []; const add = (c, v) => out.push(String(c), String(v));
    const names = groups.map(g => g.name);
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    entities.forEach(e => e.pts.forEach(([x, y]) => { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }));
    if (!isFinite(x0)) { x0 = y0 = 0; x1 = y1 = 0; }
    // fixed handles for the structural objects
    const hMS = "17", hPS = "1B", hBR = "9", hLT = "2", hLY = "1", hST = "5", hAP = "3", hDICT = "A";
    // HEADER
    add(0, "SECTION"); add(2, "HEADER");
    add(9, "$ACADVER"); add(1, "AC1015");
    add(9, "$DWGCODEPAGE"); add(3, "ANSI_1252");
    add(9, "$INSBASE"); add(10, 0); add(20, 0); add(30, 0);
    add(9, "$EXTMIN"); add(10, num(x0)); add(20, num(y0)); add(30, 0);
    add(9, "$EXTMAX"); add(10, num(x1)); add(20, num(y1)); add(30, 0);
    add(9, "$LIMMIN"); add(10, 0); add(20, 0);
    add(9, "$LIMMAX"); add(10, num(Math.max(x1, 420))); add(20, num(Math.max(y1, 297)));
    add(9, "$LTSCALE"); add(40, 1);
    add(9, "$CLAYER"); add(8, "0");
    add(9, "$LUNITS"); add(70, 2);
    add(9, "$LUPREC"); add(70, 4);
    add(9, "$MEASUREMENT"); add(70, unit === "in" ? 0 : 1);
    add(9, "$INSUNITS"); add(70, unit === "in" ? 1 : 4);
    add(9, "$HANDSEED"); add(5, "FFFFFF");
    add(0, "ENDSEC");
    // TABLES
    add(0, "SECTION"); add(2, "TABLES");
    const table = (name, handle, count, body) => { add(0, "TABLE"); add(2, name); add(5, handle); add(330, 0); add(100, "AcDbSymbolTable"); add(70, count); body && body(); add(0, "ENDTAB"); };
    table("LTYPE", hLT, 3, () => {
      [["ByBlock", "24"], ["ByLayer", "25"], ["Continuous", "26"]].forEach(([n, h]) => {
        add(0, "LTYPE"); add(5, h); add(330, hLT); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbLinetypeTableRecord");
        add(2, n); add(70, 0); add(3, n === "Continuous" ? "Solid line" : ""); add(72, 65); add(73, 0); add(40, 0); });
    });
    const layerNames = ["0"].concat(names.filter(n => n !== "0"));
    table("LAYER", hLY, layerNames.length, () => {
      layerNames.forEach((n, i) => {
        add(0, "LAYER"); add(5, H()); add(330, hLY); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbLayerTableRecord");
        add(2, n); add(70, 0); add(62, n === "0" ? 7 : (names.length > 1 ? 1 + ((i - 1) % 6) : 1)); add(6, "Continuous"); });
    });
    table("STYLE", hST, 1, () => {
      add(0, "STYLE"); add(5, "29"); add(330, hST); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbTextStyleTableRecord");
      add(2, "Standard"); add(70, 0); add(40, 0); add(41, 1); add(50, 0); add(71, 0); add(42, 2.5); add(3, "txt"); add(4, "");
    });
    table("APPID", hAP, 1, () => {
      add(0, "APPID"); add(5, "2A"); add(330, hAP); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbRegAppTableRecord"); add(2, "ACAD"); add(70, 0);
    });
    table("BLOCK_RECORD", hBR, 2, () => {
      add(0, "BLOCK_RECORD"); add(5, hMS); add(330, hBR); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbBlockTableRecord"); add(2, "*Model_Space");
      add(0, "BLOCK_RECORD"); add(5, hPS); add(330, hBR); add(100, "AcDbSymbolTableRecord"); add(100, "AcDbBlockTableRecord"); add(2, "*Paper_Space");
    });
    add(0, "ENDSEC");
    // BLOCKS
    add(0, "SECTION"); add(2, "BLOCKS");
    [["*Model_Space", hMS, "18", "19"], ["*Paper_Space", hPS, "1C", "1D"]].forEach(([n, owner, hb, he]) => {
      add(0, "BLOCK"); add(5, hb); add(330, owner); add(100, "AcDbEntity"); add(8, "0"); add(100, "AcDbBlockBegin"); add(2, n); add(70, 0);
      add(10, 0); add(20, 0); add(30, 0); add(3, n); add(1, "");
      add(0, "ENDBLK"); add(5, he); add(330, owner); add(100, "AcDbEntity"); add(8, "0"); add(100, "AcDbBlockEnd"); });
    add(0, "ENDSEC");
    // ENTITIES
    add(0, "SECTION"); add(2, "ENTITIES");
    entities.forEach(e => {
      const q = e.pts, cl = e.closed !== false;
      if (q.length < (cl ? 3 : 2)) return;
      add(0, "LWPOLYLINE"); add(5, H()); add(330, hMS); add(100, "AcDbEntity"); add(8, e.layer);
      add(100, "AcDbPolyline"); add(90, q.length); add(70, cl ? 1 : 0); add(43, 0);
      q.forEach(([x, y]) => { add(10, num(x)); add(20, num(y)); });
    });
    add(0, "ENDSEC");
    // OBJECTS
    add(0, "SECTION"); add(2, "OBJECTS");
    add(0, "DICTIONARY"); add(5, hDICT); add(330, 0); add(100, "AcDbDictionary"); add(281, 1); add(3, "ACAD_GROUP"); add(350, "C");
    add(0, "DICTIONARY"); add(5, "C"); add(330, hDICT); add(100, "AcDbDictionary"); add(281, 1);
    add(0, "ENDSEC"); add(0, "EOF");
    return out.join("\r\n") + "\r\n";
  }

  // ------------------------------------------------------------------ selection / clip / split
  const bboxOf = q => { let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity; for (const [x, y] of q) { if (x < a) a = x; if (x > c) c = x; if (y < b) b = y; if (y > d) d = y; } return [a, b, c, d]; };
  const ringArea = r => { let s = 0; for (let i = 0; i < r.length - 1; i++) s += r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1]; return Math.abs(s) / 2; };
  const closed = q => { const r = q.map(p => [p[0], p[1]]); const a = r[0], b = r[r.length - 1]; if (a[0] !== b[0] || a[1] !== b[1]) r.push([a[0], a[1]]); return r; };
  const rectPoly = ([x0, y0, x1, y1]) => [[[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]];
  const safe = s => String(s).replace(/[^A-Za-z0-9_\-]/g, "_").slice(0, 60) || "X";

  /** Clip helper: intersection of polygon q (open ring) with a multipolygon region. Returns exterior rings (open arrays). */
  function intersectRings(q, regionMP) {
    let res;
    try { res = pc().intersection([closed(q)], regionMP); } catch (e) { return []; }
    const out = [];
    for (const poly of res) { const ext = poly[0]; if (ext && ext.length > 3 && ringArea(ext) > 1e-9) out.push(ext.slice(0, -1)); }
    return out;
  }

  // ------------------------------------------------------------------ nesting depth (for "cut inside first")
  const inRing = (x, y, q) => {                       // even-odd ray casting
    let c = false;
    for (let i = 0, j = q.length - 1; i < q.length; j = i++) {
      const xi = q[i][0], yi = q[i][1], xj = q[j][0], yj = q[j][1];
      if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
    }
    return c;
  };
  /** Number of other contours that geometrically contain each contour (0 = outermost). polys in px. */
  const depthCache = new WeakMap();
  function nestingDepths(polys) {
    if (depthCache.has(polys)) return depthCache.get(polys);
    const n = polys.length, bb = polys.map(bboxOf), ar = polys.map(q => ringArea(closed(q))), depth = new Array(n).fill(0);
    const order = polys.map((_, i) => i).sort((a, b) => ar[b] - ar[a]);
    for (let a = 0; a < n; a++) {
      const i = order[a], q = polys[i], k = Math.min(7, q.length), samples = [];
      for (let s = 0; s < k; s++) samples.push(q[Math.floor(s * q.length / k)]);
      for (let b = 0; b < a; b++) {                    // only larger contours can contain i
        const j = order[b], B = bb[j], I = bb[i];
        if (ar[j] <= ar[i] || I[0] < B[0] - 1e-9 || I[2] > B[2] + 1e-9 || I[1] < B[1] - 1e-9 || I[3] > B[3] + 1e-9) continue;
        let inside = 0; for (const [x, y] of samples) if (inRing(x, y, polys[j])) inside++;
        if (inside * 2 > k) depth[i]++;
      }
    }
    depthCache.set(polys, depth); return depth;
  }

  // ------------------------------------------------------------------ tabs / bridges
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  /** Split a closed ring (open array of [x,y] in output units) into open polylines leaving n gaps of length w, evenly spaced
      along the perimeter. Gaps are nudged onto a single straight edge when one is close, so each gap is exactly w long as a chord.
      opts: {width, count, spacing}. Returns {segs:[pts], gaps:[pts], n} or null if the contour is too small. */
  function ringTabs(ring, opts) {
    const w = opts.width, m = ring.length;
    if (!(w > 0) || m < 3) return null;
    const v = ring.concat([ring[0]]), L = [], cum = [0];
    for (let i = 0; i < m; i++) { L.push(dist(v[i], v[i + 1])); cum.push(cum[i] + L[i]); }
    const P = cum[m];
    let n = opts.spacing > 0 ? Math.max(1, Math.round(P / opts.spacing)) : Math.max(1, Math.round(opts.count || 1));
    n = Math.min(n, Math.floor(P / (3 * w)));
    if (n < 1) return null;
    const rad = P / (4 * n), gaps = [];
    for (let k = 0; k < n; k++) {
      const t = (k + 0.5) * P / n; let best = t, bd = Infinity;
      for (let i = 0; i < m; i++) {
        if (L[i] < w) continue;
        const lo = cum[i] + w / 2, hi = cum[i + 1] - w / 2, c = Math.max(lo, Math.min(hi, t)), d = Math.abs(c - t);
        if (d <= rad && d < bd) { bd = d; best = c; }
      }
      gaps.push([best - w / 2, best + w / 2]);
    }
    const at = s => {
      let i = 0; while (i < m - 1 && cum[i + 1] < s) i++;
      const t = L[i] > 0 ? Math.max(0, Math.min(1, (s - cum[i]) / L[i])) : 0;
      return [v[i][0] + (v[i + 1][0] - v[i][0]) * t, v[i][1] + (v[i + 1][1] - v[i][1]) * t];
    };
    const sub = (a, b) => {
      const out = [at(a)];
      for (let i = 1; i < m; i++) if (cum[i] > a + 1e-12 && cum[i] < b - 1e-12) out.push(v[i]);
      out.push(at(b)); return out;
    };
    const dedupe = q => q.filter((p, i) => i === 0 || dist(p, q[i - 1]) > 1e-9);
    const segs = [];
    for (let k = 0; k < n - 1; k++) segs.push(dedupe(sub(gaps[k][1], gaps[k + 1][0])));
    const last = sub(gaps[n - 1][1], P), first = sub(0, gaps[0][0]);
    segs.push(dedupe(last.concat(first.slice(1))));
    return { segs: segs.filter(q => q.length >= 2), gaps: gaps.map(g => sub(g[0], g[1])), n };
  }

  // ------------------------------------------------------------------ cut ordering
  /** units: [{paths:[{pts,closed}], depth}]. Reorders (and rotates closed rings / cyclic tab segments to start nearest the
      previous end point) according to o.insideFirst (deepest nesting first) and o.nearest (greedy nearest neighbour). */
  function orderUnits(units, o) {
    const insideFirst = !!o.insideFirst, nearest = !!o.nearest;
    if (!insideFirst && !nearest) return units;
    const tiers = [];
    if (insideFirst) {
      const by = new Map(); units.forEach(u => { if (!by.has(u.depth)) by.set(u.depth, []); by.get(u.depth).push(u); });
      [...by.keys()].sort((a, b) => b - a).forEach(d => tiers.push(by.get(d)));
    } else tiers.push(units.slice());
    const out = []; let pos = [0, 0];
    for (const tier of tiers) {
      if (!nearest || tier.length > 6000) { tier.forEach(u => out.push(u)); if (tier.length) pos = endOf(tier[tier.length - 1]); continue; }
      const rest = tier.slice();
      while (rest.length) {
        let bi = 0, bd = Infinity, bk = 0;
        for (let i = 0; i < rest.length; i++) {
          const u = rest[i], cands = u.paths.length === 1 && u.paths[0].closed ? u.paths[0].pts : u.paths.map(p => p.pts[0]);
          for (let k = 0; k < cands.length; k++) { const d = (cands[k][0] - pos[0]) ** 2 + (cands[k][1] - pos[1]) ** 2; if (d < bd) { bd = d; bi = i; bk = k; } }
        }
        const u = rest.splice(bi, 1)[0];
        if (u.paths.length === 1 && u.paths[0].closed) { const q = u.paths[0].pts; u.paths[0] = { pts: q.slice(bk).concat(q.slice(0, bk)), closed: true }; }
        else u.paths = u.paths.slice(bk).concat(u.paths.slice(0, bk));
        out.push(u); pos = endOf(u);
      }
    }
    return out;
  }
  function endOf(u) { const p = u.paths[u.paths.length - 1]; return p.closed ? p.pts[0] : p.pts[p.pts.length - 1]; }

  // ------------------------------------------------------------------ plan: selection -> clip -> tabs -> order -> entities
  /** polys: px coords (y down). Options (o):
        pxW, pxH, scale (units/px, x), scaleY (defaults to scale), unit, selected (ids), regions [{rect px, label}], clip,
        split none|layers|files, groupBy contour|cell, insideFirst, nearest, innerOuterLayers (CUT_INNER / CUT_OUTER, one-file mode),
        isHole [bool per contour], tabs {width, count, spacing, allOuter, ids, skipHoles}
      Returns {entities:[{layer, pts (output units, y up), closed, cid, depth, seq}], layers, gaps:[{cid, pts}], stats} */
  function buildPlan(polys, o) {
    const { pxW, pxH } = o, sx = o.scale, sy = o.scaleY || o.scale, n = polys.length;
    const clip = !!o.clip, split = o.split || "none", groupBy = o.groupBy || "contour";
    let ids;
    if (o.selected == null) ids = polys.map((_, i) => i);
    else { ids = [...new Set(o.selected.map(Number))].sort((a, b) => a - b); if (ids.some(i => !(i >= 0 && i < n))) throw new Error("selected contains an unknown contour id"); }
    if (!ids.length) throw new Error("No contours selected");
    const cells = []; const seen = new Set();
    (o.regions || []).forEach((r, k) => {
      let [x0, y0, x1, y1] = r.rect.map(Number); [x0, x1] = [Math.max(0, x0), Math.min(pxW, x1)].sort((a, b) => a - b); [y0, y1] = [Math.max(0, y0), Math.min(pxH, y1)].sort((a, b) => a - b);
      if (x1 - x0 <= 0 || y1 - y0 <= 0) return;
      let label = safe(r.label || "AREA" + (k + 1)); while (seen.has(label)) label += "_"; seen.add(label);
      cells.push({ label, rect: [x0, y0, x1, y1], mp: [rectPoly([x0, y0, x1, y1])] });
    });
    if ((o.regions || []).length && !cells.length) throw new Error("Area of interest is empty");
    let area = null;
    if (cells.length) area = { mp: cells.length === 1 ? cells[0].mp : pc().union(...cells.map(c => c.mp)), rects: cells.map(c => c.rect) };
    const bb = {}; ids.forEach(i => bb[i] = bboxOf(polys[i]));
    const rectsTouch = (b, rects) => rects.some(([x0, y0, x1, y1]) => b[0] < x1 && b[2] > x0 && b[1] < y1 && b[3] > y0);
    function pieces(i, region) {                       // px rings of contour i within a region
      if (!region) return [polys[i]];
      if (!rectsTouch(bb[i], region.rects)) return [];
      const rings = intersectRings(polys[i], region.mp);
      if (!rings.length) return [];
      return clip ? rings : [polys[i]];
    }
    const toOut = q => q.map(([x, y]) => [x * sx, (pxH - y) * sy]);
    let groups;                                        // [[name, [{cid, ring}]]]
    const wrap = (i, region) => pieces(i, region).map(ring => ({ cid: i, ring }));
    if (split === "none") groups = [["CUT", ids.flatMap(i => wrap(i, area))]];
    else if (split === "layers" || split === "files") {
      if (groupBy === "cell") {
        if (!cells.length) throw new Error("Group by cell needs grid cells or a drawn region");
        groups = cells.map(c => ["CUT_" + c.label, ids.flatMap(i => wrap(i, { mp: c.mp, rects: [c.rect] }))]);
      } else if (groupBy === "contour") groups = ids.map(i => ["CUT_" + String(i).padStart(3, "0"), wrap(i, area)]);
      else throw new Error("group_by must be 'contour' or 'cell'");
    } else throw new Error("split must be none, layers or files");
    groups = groups.filter(g => g[1].length);
    if (!groups.length) throw new Error("Nothing to export: selection does not overlap the area of interest");

    const needDepth = o.insideFirst || o.innerOuterLayers;
    const depth = needDepth ? nestingDepths(polys) : null;
    const isHole = i => o.isHole ? !!o.isHole[i] : (depth ? depth[i] % 2 === 1 : false);
    const T = o.tabs && o.tabs.width > 0 ? o.tabs : null, flagged = new Set(T ? (T.ids || []).map(Number) : []);
    const gaps = [], stats = { units: 0, tabbed: 0, tabs: 0, tabSkipped: 0, maxDepth: 0 };
    let seqBase = 0;
    const planGroup = (name, items) => {
      let units = items.map(({ cid, ring }) => {
        const pts = toOut(ring), d = depth ? depth[cid] : 0, hole = isHole(cid);
        const layer = split === "none" ? (o.innerOuterLayers ? (d > 0 ? "CUT_INNER" : "CUT_OUTER") : "CUT") : name;
        let paths = [{ pts, closed: true }];
        if (T && ((T.allOuter && !hole) || (flagged.has(cid) && !(T.skipHoles && hole)))) {
          const r = ringTabs(pts, T);
          if (r) { paths = r.segs.map(q => ({ pts: q, closed: false })); r.gaps.forEach(g => gaps.push({ cid, pts: g })); stats.tabbed++; stats.tabs += r.n; }
          else stats.tabSkipped++;
        }
        return { layer, cid, depth: d, paths };
      });
      return units;
    };
    let ordered;
    if (split === "files") ordered = groups.flatMap(([name, items]) => orderUnits(planGroup(name, items), o));
    else ordered = orderUnits(groups.flatMap(([name, items]) => planGroup(name, items)), o);
    const entities = [];
    ordered.forEach((u, k) => { stats.units++; stats.maxDepth = Math.max(stats.maxDepth, u.depth); u.paths.forEach(p => entities.push({ layer: u.layer, pts: p.pts, closed: p.closed, cid: u.cid, depth: u.depth, seq: k + 1 })); });
    const layers = []; entities.forEach(e => { if (layers.indexOf(e.layer) < 0) layers.push(e.layer); });
    return { entities, layers, gaps, stats };
  }

  /** Compatibility wrapper: plan grouped by layer -> [{name, polys}] (output units). */
  function buildGroups(polys, o) {
    const plan = buildPlan(polys, o), g = new Map();
    plan.entities.forEach(e => { if (!g.has(e.layer)) g.set(e.layer, []); g.get(e.layer).push(e.pts); });
    return [...g.entries()].map(([name, ps]) => ({ name, polys: ps }));
  }

  function shiftToOrigin(entities, ref) {
    let ox = Infinity, oy = Infinity; entities.forEach(e => e.pts.forEach(([x, y]) => { if (x < ox) ox = x; if (y < oy) oy = y; }));
    return entities.map(e => Object.assign({}, e, { pts: e.pts.map(([x, y]) => [x - ox, y - oy]) }));
  }

  // ------------------------------------------------------------------ ZIP (store or deflate-raw via CompressionStream)
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  async function deflateRaw(bytes) {
    if (typeof CompressionStream === "undefined") return null;
    try {
      const cs = new CompressionStream("deflate-raw"); const w = cs.writable.getWriter(); w.write(bytes); w.close();
      return new Uint8Array(await new Response(cs.readable).arrayBuffer());
    } catch (e) { return null; }
  }
  /** files: [{name, data:Uint8Array}] -> Uint8Array zip */
  async function makeZip(files) {
    const enc = new TextEncoder(), parts = [], central = []; let off = 0;
    const d = new Date(), dosT = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), dosD = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    for (const f of files) {
      const name = enc.encode(f.name), crc = crc32(f.data); let comp = await deflateRaw(f.data), method = 8;
      if (!comp || comp.length >= f.data.length) { comp = f.data; method = 0; }
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, method, true);
      lh.setUint16(10, dosT, true); lh.setUint16(12, dosD, true); lh.setUint32(14, crc, true); lh.setUint32(18, comp.length, true); lh.setUint32(22, f.data.length, true); lh.setUint16(26, name.length, true);
      parts.push(new Uint8Array(lh.buffer), name, comp);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, method, true);
      ch.setUint16(12, dosT, true); ch.setUint16(14, dosD, true); ch.setUint32(16, crc, true); ch.setUint32(20, comp.length, true); ch.setUint32(24, f.data.length, true); ch.setUint16(28, name.length, true); ch.setUint32(42, off, true);
      central.push(new Uint8Array(ch.buffer), name);
      off += 30 + name.length + comp.length;
    }
    const csize = central.reduce((a, b) => a + b.length, 0);
    const end = new DataView(new ArrayBuffer(22)); end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, csize, true); end.setUint32(16, off, true);
    const all = parts.concat(central, [new Uint8Array(end.buffer)]); const total = all.reduce((a, b) => a + b.length, 0), res = new Uint8Array(total); let p = 0;
    for (const a of all) { res.set(a, p); p += a.length; }
    return res;
  }

  /** High level export: returns {bytes:Uint8Array|string, mime, filename, paths, groups, plan} */
  async function exportDxf(polys, o) {
    const plan = buildPlan(polys, o); let ents = plan.entities;
    const enc = new TextEncoder(), paths = ents.length;
    if (o.split === "files") {
      const files = plan.layers.map(l => { let es = ents.filter(e => e.layer === l); if (o.zeroOrigin) es = shiftToOrigin(es); return { name: l + ".dxf", data: enc.encode(writeEntities(es, o.unit)) }; });
      return { bytes: await makeZip(files), mime: "application/zip", filename: "cut_files.zip", paths, groups: plan.layers.length, plan };
    }
    if (o.zeroOrigin) ents = shiftToOrigin(ents);
    return { bytes: enc.encode(writeEntities(ents, o.unit)), mime: "application/dxf", filename: "cut.dxf", paths, groups: plan.layers.length, plan };
  }

  const api = { writeDxf, writeEntities, buildPlan, buildGroups, exportDxf, makeZip, crc32, nestingDepths, ringTabs, orderUnits };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.I2D_DXF = api;
})(typeof self !== "undefined" ? self : this);
